using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Azure;
using Azure.Core;
using Azure.Identity;
using Azure.ResourceManager;
using Azure.ResourceManager.KeyVault;
using Azure.ResourceManager.Resources;
using Azure.ResourceManager.ServiceBus;
using IqonScripts.Models;
using IqonScripts.Utils;

namespace IqonScripts.Services;

/// <summary>
/// Service for working with Azure resources
/// </summary>
public class AzureResourceService
{
    private readonly ArmClient _armClient;
    private readonly LoggerService _logger;
    private readonly ResourceGroupResource _sourceResourceGroup;
    private readonly HttpClient _httpClient;

    // Regular expressions for extracting tenant IDs from resource names
    private readonly Regex _keyVaultTenantIdRegex = new Regex(@"kv-iqonsticos(\d+)$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private readonly Regex _serviceBusTenantIdRegex = new Regex(@"sb-iqon-sticos-?(\d+)$", RegexOptions.Compiled | RegexOptions.IgnoreCase);
    private readonly Regex _webAppTenantIdRegex = new Regex(@"app-iqon-sticos-?(\d+)$", RegexOptions.Compiled | RegexOptions.IgnoreCase);

    /// <summary>
    /// Initializes a new instance of the <see cref="AzureResourceService"/> class.
    /// </summary>
    /// <param name="armClient">The ARM client</param>
    /// <param name="logger">The logger service</param>
    /// <param name="sourceResourceGroupName">The source resource group name</param>
    public AzureResourceService(ArmClient armClient, LoggerService logger, string sourceResourceGroupName)
    {
        _armClient = armClient;
        _logger = logger;
        _httpClient = new HttpClient();

        // Get the default subscription
        var subscription = _armClient.GetDefaultSubscription();
        
        // Get the source resource group
        _sourceResourceGroup = subscription.GetResourceGroup(sourceResourceGroupName);
        
        if (_sourceResourceGroup == null)
        {
            throw new ArgumentException($"Source resource group '{sourceResourceGroupName}' not found.");
        }
    }

    /// <summary>
    /// Discovers resources to move in the source resource group
    /// </summary>
    /// <returns>A list of resources to move</returns>
    public async Task<List<ResourceInfo>> DiscoverResourcesToMoveAsync()
    {
        var resourcesToMove = new List<ResourceInfo>();
        
        _logger.LogInformation($"Discovering resources in resource group '{_sourceResourceGroup.Data.Name}'...");
        
        // Discover KeyVaults
        await DiscoverKeyVaultsAsync(resourcesToMove);
        
        // Discover Service Buses
        await DiscoverServiceBusesAsync(resourcesToMove);
        
        // Find target resource groups for each resource
        await FindTargetResourceGroupsAsync(resourcesToMove);
        
        return resourcesToMove;
    }

    /// <summary>
    /// Moves resources to their target resource groups
    /// </summary>
    /// <param name="resources">The resources to move</param>
    /// <param name="dryRun">Whether to run in dry run mode (no actual changes)</param>
    /// <returns>The result of the move operation</returns>
    public async Task<ScriptResult> MoveResourcesAsync(List<ResourceInfo> resources, bool dryRun)
    {
        var result = new ScriptResult
        {
            DryRun = dryRun,
            ProcessedResources = resources
        };
        
        if (dryRun)
        {
            _logger.LogInformation("Running in DRY RUN mode. No resources will be moved.");
            result.Success = true;
            return result;
        }
        
        _logger.LogInformation("Moving resources...");
        var startTime = DateTime.UtcNow;
        
        foreach (var resource in resources)
        {
            try
            {
                _logger.LogInformation($"Moving {resource.Name} to {resource.TargetResourceGroup}...");
                
                // Get the subscription
                var subscription = _armClient.GetDefaultSubscription();
                
                // Get the target resource group
                var targetResourceGroup = await subscription.GetResourceGroupAsync(resource.TargetResourceGroup);
                
                if (targetResourceGroup?.Value == null)
                {
                    var errorMessage = $"Target resource group '{resource.TargetResourceGroup}' not found.";
                    _logger.LogError(errorMessage);
                    result.Errors.Add(errorMessage);
                    continue;
                }
                
                // Move the resource
                var moveSuccess = await MoveResourceToResourceGroupAsync(
                    subscription.Id.SubscriptionId,
                    resource.SourceResourceGroup,
                    resource.TargetResourceGroup,
                    resource.Id);
                
                if (moveSuccess)
                {
                    _logger.LogSuccess($"Successfully moved {resource.Name} to {resource.TargetResourceGroup}");
                }
                else
                {
                    var errorMessage = $"Failed to move {resource.Name} to {resource.TargetResourceGroup}";
                    _logger.LogError(errorMessage);
                    result.Errors.Add(errorMessage);
                }
            }
            catch (Exception ex)
            {
                var errorMessage = $"Failed to move {resource.Name} to {resource.TargetResourceGroup}: {ex.Message}";
                _logger.LogError(errorMessage, ex);
                result.Errors.Add(errorMessage);
            }
        }
        
        var endTime = DateTime.UtcNow;
        result.ExecutionTimeMs = (long)(endTime - startTime).TotalMilliseconds;
        result.Success = result.Errors.Count == 0;
        
        return result;
    }

    /// <summary>
    /// Moves a resource to a different resource group using the Azure PowerShell cmdlet
    /// </summary>
    /// <param name="subscriptionId">The subscription ID</param>
    /// <param name="sourceResourceGroup">The source resource group</param>
    /// <param name="targetResourceGroup">The target resource group</param>
    /// <param name="resourceId">The resource ID</param>
    /// <returns>Whether the move was successful</returns>
    private async Task<bool> MoveResourceToResourceGroupAsync(
        string subscriptionId,
        string sourceResourceGroup,
        string targetResourceGroup,
        string resourceId)
    {
        try
        {
            // Use PowerShell (via the Azure CLI) to move resources
            // This is a more reliable method than using the ARM REST API directly
            var powershellCommand = $"Move-AzResource -ResourceId \"{resourceId}\" -DestinationResourceGroupName \"{targetResourceGroup}\" -Force";
            var command = $"powershell -Command \"{powershellCommand}\"";
            
            // Create process to run PowerShell
            var process = new System.Diagnostics.Process
            {
                StartInfo = new System.Diagnostics.ProcessStartInfo
                {
                    FileName = "powershell.exe",
                    Arguments = $"-Command \"{powershellCommand}\"",
                    RedirectStandardOutput = true,
                    RedirectStandardError = true,
                    UseShellExecute = false,
                    CreateNoWindow = true
                }
            };
            
            _logger.LogVerbose($"Executing PowerShell command: {powershellCommand}");
            
            process.Start();
            var output = await process.StandardOutput.ReadToEndAsync();
            var error = await process.StandardError.ReadToEndAsync();
            await process.WaitForExitAsync();
            
            if (process.ExitCode != 0)
            {
                _logger.LogError($"PowerShell command failed with exit code {process.ExitCode}: {error}");
                return false;
            }
            
            _logger.LogVerbose($"PowerShell command output: {output}");
            return true;
        }
        catch (Exception ex)
        {
            _logger.LogError($"Failed to move resource: {ex.Message}", ex);
            return false;
        }
    }

    /// <summary>
    /// Finds KeyVaults in the source resource group
    /// </summary>
    /// <param name="resources">The list to add found resources to</param>
    private async Task DiscoverKeyVaultsAsync(List<ResourceInfo> resources)
    {
        _logger.LogInformation($"Looking for KeyVaults in resource group '{_sourceResourceGroup.Data.Name}'...");
        _logger.LogInformation($"Using KeyVault pattern: {_keyVaultTenantIdRegex}");
        
        // Use server-side filtering for KeyVaults - much more efficient than fetching all resources
        _logger.LogInformation("Looking for KeyVaults using server-side filtered query...");
        int keyVaultCount = 0;
        
        // Pass the filter as a direct parameter to the GetGenericResourcesAsync method
        await foreach (var resource in _sourceResourceGroup.GetGenericResourcesAsync(filter: "resourceType eq 'Microsoft.KeyVault/vaults'"))
        {
            keyVaultCount++;
            _logger.LogInformation($"Found KeyVault: {resource.Data.Name}");
            
            var match = _keyVaultTenantIdRegex.Match(resource.Data.Name);
            _logger.LogInformation($"Matching '{resource.Data.Name}' against pattern '{_keyVaultTenantIdRegex}' - IsMatch: {match.Success}");
            
            if (match.Success)
            {
                var tenantId = match.Groups[1].Value;
                
                resources.Add(new ResourceInfo
                {
                    Id = resource.Id,
                    Name = resource.Data.Name,
                    Type = "KeyVault",
                    TenantId = tenantId,
                    SourceResourceGroup = _sourceResourceGroup.Data.Name
                });
                
                _logger.LogInformation($"Found KeyVault: {resource.Data.Name} with tenant ID: {tenantId}");
            }
            else
            {
                _logger.LogInformation($"Skipping KeyVault {resource.Data.Name} as it doesn't match the expected naming pattern");
            }
        }
        
        if (keyVaultCount == 0)
        {
            _logger.LogWarning("No KeyVaults found in the resource group. This might indicate permission issues or the KeyVault doesn't exist.");
        }
    }

    /// <summary>
    /// Finds Service Buses in the source resource group
    /// </summary>
    /// <param name="resources">The list to add found resources to</param>
    private async Task DiscoverServiceBusesAsync(List<ResourceInfo> resources)
    {
        _logger.LogInformation($"Looking for Service Buses in resource group '{_sourceResourceGroup.Data.Name}'...");
        _logger.LogInformation($"Using Service Bus pattern: {_serviceBusTenantIdRegex}");
        
        // Use server-side filtering for Service Buses - much more efficient than fetching all resources
        _logger.LogInformation("Looking for Service Buses using server-side filtered query...");
        int serviceBusCount = 0;
        
        await foreach (var resource in _sourceResourceGroup.GetGenericResourcesAsync(filter: "resourceType eq 'Microsoft.ServiceBus/namespaces'"))
        {
            serviceBusCount++;
            _logger.LogInformation($"Found Service Bus: {resource.Data.Name}");
            
            var match = _serviceBusTenantIdRegex.Match(resource.Data.Name);
            _logger.LogInformation($"Matching '{resource.Data.Name}' against pattern '{_serviceBusTenantIdRegex}' - IsMatch: {match.Success}");
            
            if (match.Success)
            {
                var tenantId = match.Groups[1].Value;
                
                resources.Add(new ResourceInfo
                {
                    Id = resource.Id,
                    Name = resource.Data.Name,
                    Type = "ServiceBus",
                    TenantId = tenantId,
                    SourceResourceGroup = _sourceResourceGroup.Data.Name
                });
                
                _logger.LogInformation($"Found Service Bus: {resource.Data.Name} with tenant ID: {tenantId}");
            }
            else
            {
                _logger.LogInformation($"Skipping Service Bus {resource.Data.Name} as it doesn't match the expected naming pattern");
            }
        }
        
        if (serviceBusCount == 0)
        {
            _logger.LogWarning("No Service Bus namespaces found in the resource group. This might indicate permission issues or the Service Bus doesn't exist.");
        }
    }

    /// <summary>
    /// Finds target resource groups for the resources to move
    /// </summary>
    /// <param name="resources">The resources to find target resource groups for</param>
    private async Task FindTargetResourceGroupsAsync(List<ResourceInfo> resources)
    {
        if (resources.Count == 0)
        {
            _logger.LogWarning("No resources found to move.");
            return;
        }
        
        _logger.LogInformation("Finding target resource groups...");
        
        // Get the default subscription
        var subscription = _armClient.GetDefaultSubscription();
        
        // Group resources by tenant ID
        var resourcesByTenantId = resources.GroupBy(r => r.TenantId);
        
        foreach (var group in resourcesByTenantId)
        {
            var tenantId = group.Key;
            
            if (string.IsNullOrEmpty(tenantId))
            {
                _logger.LogWarning($"Skipping resources with no tenant ID");
                continue;
            }
            
            // Look for resource groups with web apps matching the tenant ID pattern
            var webAppResourceGroupName = string.Empty;
            
            await foreach (var resourceGroup in subscription.GetResourceGroups().GetAllAsync())
            {
                // Check if this resource group contains a web app with the expected name pattern
                bool found = false;
                
                // Filter to only get web app resources - much more efficient with large resource groups
                await foreach (var webApp in resourceGroup.GetGenericResourcesAsync(filter: "resourceType eq 'Microsoft.Web/sites'"))
                {
                    var match = _webAppTenantIdRegex.Match(webApp.Data.Name);
                    if (match.Success && match.Groups[1].Value == tenantId)
                    {
                        webAppResourceGroupName = resourceGroup.Data.Name;
                        found = true;
                        _logger.LogVerbose($"Found target resource group {webAppResourceGroupName} for tenant ID {tenantId}");
                        break;
                    }
                }
                
                if (found) break;
            }
            
            if (string.IsNullOrEmpty(webAppResourceGroupName))
            {
                _logger.LogWarning($"No target resource group found for tenant ID {tenantId}");
                continue;
            }
            
            // Set the target resource group for all resources with this tenant ID
            foreach (var resource in group)
            {
                resource.TargetResourceGroup = webAppResourceGroupName;
                _logger.LogInformation($"Resource {resource.Name} will be moved to {resource.TargetResourceGroup}");
            }
        }
        
        // Filter out resources with no target resource group
        var resourcesWithNoTarget = resources.Where(r => string.IsNullOrEmpty(r.TargetResourceGroup)).ToList();
        foreach (var resource in resourcesWithNoTarget)
        {
            _logger.LogWarning($"Removing {resource.Name} from move list as no target resource group was found");
            resources.Remove(resource);
        }
    }
}
