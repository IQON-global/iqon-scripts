namespace IqonScripts.Models;

public class CommandOptions
{
    /// <summary>
    /// The subscription ID to use for Azure operations
    /// </summary>
    public string? SubscriptionId { get; set; }
    
    /// <summary>
    /// The source resource group where orphaned resources are located
    /// </summary>
    public string SourceResourceGroup { get; set; } = "rg-iqon-sticos";
    
    /// <summary>
    /// Whether to run in dry run mode (preview only)
    /// </summary>
    public bool DryRun { get; set; } = false;
    
    /// <summary>
    /// Whether to show verbose logging
    /// </summary>
    public bool Verbose { get; set; } = false;
    
    /// <summary>
    /// The type of script to run
    /// </summary>
    public string ScriptType { get; set; } = "move-resources";
}
